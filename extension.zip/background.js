var T = { exports: {} }, L = T.exports, N;
function O() {
  return N || (N = 1, function(d, f) {
    (function(u, a) {
      a(d);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : L, function(u) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        u.exports = globalThis.browser;
      else {
        const a = "The message port closed before a response was received.", p = (o) => {
          const A = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(A).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class E extends WeakMap {
            constructor(s, n = void 0) {
              super(n), this.createItem = s;
            }
            get(s) {
              return this.has(s) || this.set(s, this.createItem(s)), super.get(s);
            }
          }
          const $ = (e) => e && typeof e == "object" && typeof e.then == "function", S = (e, s) => (...n) => {
            o.runtime.lastError ? e.reject(new Error(o.runtime.lastError.message)) : s.singleCallbackArg || n.length <= 1 && s.singleCallbackArg !== !1 ? e.resolve(n[0]) : e.resolve(n);
          }, w = (e) => e == 1 ? "argument" : "arguments", j = (e, s) => function(t, ...i) {
            if (i.length < s.minArgs)
              throw new Error(`Expected at least ${s.minArgs} ${w(s.minArgs)} for ${e}(), got ${i.length}`);
            if (i.length > s.maxArgs)
              throw new Error(`Expected at most ${s.maxArgs} ${w(s.maxArgs)} for ${e}(), got ${i.length}`);
            return new Promise((m, l) => {
              if (s.fallbackToNoCallback)
                try {
                  t[e](...i, S({
                    resolve: m,
                    reject: l
                  }, s));
                } catch (r) {
                  console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, r), t[e](...i), s.fallbackToNoCallback = !1, s.noCallback = !0, m();
                }
              else s.noCallback ? (t[e](...i), m()) : t[e](...i, S({
                resolve: m,
                reject: l
              }, s));
            });
          }, R = (e, s, n) => new Proxy(s, {
            apply(t, i, m) {
              return n.call(i, e, ...m);
            }
          });
          let y = Function.call.bind(Object.prototype.hasOwnProperty);
          const k = (e, s = {}, n = {}) => {
            let t = /* @__PURE__ */ Object.create(null), i = {
              has(l, r) {
                return r in e || r in t;
              },
              get(l, r, c) {
                if (r in t)
                  return t[r];
                if (!(r in e))
                  return;
                let g = e[r];
                if (typeof g == "function")
                  if (typeof s[r] == "function")
                    g = R(e, e[r], s[r]);
                  else if (y(n, r)) {
                    let b = j(r, n[r]);
                    g = R(e, e[r], b);
                  } else
                    g = g.bind(e);
                else if (typeof g == "object" && g !== null && (y(s, r) || y(n, r)))
                  g = k(g, s[r], n[r]);
                else if (y(n, "*"))
                  g = k(g, s[r], n["*"]);
                else
                  return Object.defineProperty(t, r, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return e[r];
                    },
                    set(b) {
                      e[r] = b;
                    }
                  }), g;
                return t[r] = g, g;
              },
              set(l, r, c, g) {
                return r in t ? t[r] = c : e[r] = c, !0;
              },
              defineProperty(l, r, c) {
                return Reflect.defineProperty(t, r, c);
              },
              deleteProperty(l, r) {
                return Reflect.deleteProperty(t, r);
              }
            }, m = Object.create(e);
            return new Proxy(m, i);
          }, C = (e) => ({
            addListener(s, n, ...t) {
              s.addListener(e.get(n), ...t);
            },
            hasListener(s, n) {
              return s.hasListener(e.get(n));
            },
            removeListener(s, n) {
              s.removeListener(e.get(n));
            }
          }), _ = new E((e) => typeof e != "function" ? e : function(n) {
            const t = k(n, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            e(t);
          }), q = new E((e) => typeof e != "function" ? e : function(n, t, i) {
            let m = !1, l, r = new Promise((h) => {
              l = function(x) {
                m = !0, h(x);
              };
            }), c;
            try {
              c = e(n, t, l);
            } catch (h) {
              c = Promise.reject(h);
            }
            const g = c !== !0 && $(c);
            if (c !== !0 && !g && !m)
              return !1;
            const b = (h) => {
              h.then((x) => {
                i(x);
              }, (x) => {
                let P;
                x && (x instanceof Error || typeof x.message == "string") ? P = x.message : P = "An unexpected error occurred", i({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: P
                });
              }).catch((x) => {
                console.error("Failed to send onMessage rejected reply", x);
              });
            };
            return b(g ? c : r), !0;
          }), B = ({
            reject: e,
            resolve: s
          }, n) => {
            o.runtime.lastError ? o.runtime.lastError.message === a ? s() : e(new Error(o.runtime.lastError.message)) : n && n.__mozWebExtensionPolyfillReject__ ? e(new Error(n.message)) : s(n);
          }, M = (e, s, n, ...t) => {
            if (t.length < s.minArgs)
              throw new Error(`Expected at least ${s.minArgs} ${w(s.minArgs)} for ${e}(), got ${t.length}`);
            if (t.length > s.maxArgs)
              throw new Error(`Expected at most ${s.maxArgs} ${w(s.maxArgs)} for ${e}(), got ${t.length}`);
            return new Promise((i, m) => {
              const l = B.bind(null, {
                resolve: i,
                reject: m
              });
              t.push(l), n.sendMessage(...t);
            });
          }, F = {
            devtools: {
              network: {
                onRequestFinished: C(_)
              }
            },
            runtime: {
              onMessage: C(q),
              onMessageExternal: C(q),
              sendMessage: M.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: M.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, v = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return A.privacy = {
            network: {
              "*": v
            },
            services: {
              "*": v
            },
            websites: {
              "*": v
            }
          }, k(o, F, A);
        };
        u.exports = p(chrome);
      }
    });
  }(T)), T.exports;
}
O();
async function U(d, f) {
  try {
    const a = await (await fetch("https://requests.cs2inspects.com/newrequests", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        module: f,
        method: "inspectlink",
        inspectlink: d,
        steamid: "",
        sessionid: "7b60cfa1-236e-499d-b65e-36912c6b51f2",
        map: "default",
        view: "default"
      })
    })).json();
    return a.id ? (console.log("Request processed, starting polling...", a), await W()) : { error: "Unexpected response status" };
  } catch (u) {
    return { error: u.message };
  }
}
async function W() {
  const d = "7b60cfa1-236e-499d-b65e-36912c6b51f2";
  let f = 0;
  const u = 30, a = 2e3;
  for (; f < u; ) {
    f++, console.log(`Polling attempt ${f}`);
    try {
      const o = await (await fetch(`https://requests.cs2inspects.com/requestlist2?sessionid=${d}`, {
        method: "GET",
        headers: {
          Accept: "application/json"
        }
      })).json();
      if (o.requestlist && o.requestlist.length > 0) {
        const A = o.requestlist[0];
        if ([3, 15].includes(A.status_id))
          return console.log("Request completed successfully", A), A.file;
        A.status_id === 2 ? console.log("Request still in progress", A) : console.log("Unexpected status", A);
      }
      await new Promise((A) => setTimeout(A, a));
    } catch (p) {
      console.error("Polling error:", p), await new Promise((o) => setTimeout(o, a));
    }
  }
  return { error: "Max polling attempts reached without completion" };
}
function I() {
  chrome.runtime.onMessage.addListener((d, f, u) => {
    if (d.type === "newRequests")
      return U(d.href, d.module).then((a) => u({ status: "success", data: a })).catch((a) => {
        u({ status: "error", error: a.message });
      }), !0;
  });
}
console.log("background loaded");
async function D() {
  I();
}
D();
